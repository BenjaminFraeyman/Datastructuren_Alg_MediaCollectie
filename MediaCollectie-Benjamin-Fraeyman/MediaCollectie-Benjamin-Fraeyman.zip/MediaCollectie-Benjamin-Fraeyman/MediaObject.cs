﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Net;
using System.Collections.Specialized;
using ExifLibrary;
using AForge;
using AForge.Imaging;
using AForge.Imaging.Filters;
using AForge.Math;
using System.Runtime.InteropServices;
using System.Collections;

namespace MediaCollectie_Benjamin_Fraeyman
{
    public class MediaObject
    {
        public string fileName { get; set; }
        public int size { get; set; }
        public DateTime datum { get; set; }
        public Bitmap bmp { get; set; }
        public double grayMean { get; set; }
        private ImageFile metadata;
        public GPSLatitudeLongitude locationlat;
        public GPSLatitudeLongitude locationlon;
        public uint distancelat;
        public uint distancelon;
        public double distancezero;
        public double distancehuidige;
        public MediaObject(string FileName, int Size, DateTime Datum)
        {
            fileName = FileName;
            size = Size;
            datum = Datum;
        }
        public void AddMetaData(ImageFile data)
        {
            metadata = data;
        }
        public void ShowMetaData()
        {
            foreach (ExifProperty item in metadata.Properties.Values)
            {
                Console.WriteLine(item);
            }

        }
        public void Geotags()
        {
            try
            {
                locationlat = metadata.Properties[ExifTag.GPSLatitude] as GPSLatitudeLongitude;
                locationlon = metadata.Properties[ExifTag.GPSLongitude] as GPSLatitudeLongitude;
                distancelat = locationlat.Degrees.Numerator * 3600 + locationlat.Minutes.Numerator * 60 + locationlat.Seconds.Numerator;
                distancelon = locationlon.Degrees.Numerator * 3600 + locationlon.Minutes.Numerator * 60 + locationlon.Seconds.Numerator;
                distancezero = Math.Sqrt(distancelat * distancelat + distancelon * distancelon);
            }
            catch
            {
                locationlat = null;
                locationlon = null;
                distancelat = 0;
                distancelon = 0;
            }
        }



    }

    public class Distance
    {
        public static double CalcDistance(double lat1, double lon1, double lat2, double lon2)
        {
            double theta = lon1 - lon2;
            double dist = Math.Sin(Deg2Rad(lat1)) * Math.Sin(Deg2Rad(lat2)) + Math.Cos(Deg2Rad(lat1)) * Math.Cos(Deg2Rad(lat2)) * Math.Cos(Deg2Rad(theta));
            dist = Math.Acos(dist);
            dist = Rad2Deg(dist);
            dist = dist * 60 * 1.1515;
            dist = dist * 1.609344;
            return (dist);
        }
        private static double Deg2Rad(double deg)
        {
            return (deg * Math.PI / 180.0);
        }

        private static double Rad2Deg(double rad)
        {
            return (rad / Math.PI * 180.0);
        }
    }

    class Get_Current_Location
    {
        private static string IPRequestHelper(string url, string ipAddress)
        {
            string checkURL = url + ipAddress;
            HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
            StreamReader responseStream = new StreamReader(objResponse.GetResponseStream());
            string responseRead = responseStream.ReadToEnd();
            responseStream.Close();
            responseStream.Dispose();
            return responseRead;
        }

        public static string[] GetCurrentLocation(List<MediaObject> mediaList)
        {
            string strHostName = Dns.GetHostName();
            IPHostEntry ipEntry = Dns.GetHostEntry(strHostName);
            IPAddress[] addr = ipEntry.AddressList;
            string ipAddress = addr[0].ToString();
            string strReturnVal;
            string ipResponse = IPRequestHelper("http://ip-api.com/xml/", ipAddress);
            XmlDocument ipInfoXML = new XmlDocument();
            ipInfoXML.LoadXml(ipResponse);
            XmlNodeList responseXML = ipInfoXML.GetElementsByTagName("query");
            NameValueCollection dataXML = new NameValueCollection();
            dataXML.Add(responseXML.Item(0).ChildNodes[2].InnerText, responseXML.Item(0).ChildNodes[2].Value);
            strReturnVal = responseXML.Item(0).ChildNodes[1].InnerText.ToString(); // Country
            strReturnVal += "(" + responseXML.Item(0).ChildNodes[2].InnerText.ToString() + ")";  // Country Code
            string lat = responseXML.Item(0).ChildNodes[7].InnerText.ToString();
            string lng = responseXML.Item(0).ChildNodes[8].InnerText.ToString();
            string newLat = lat.Replace('.', ',');
            //Convert.ToUInt32(newLat);
            string newLng = lng.Replace('.', ',');
            string[] coords = new string[2];
            coords[0] = newLat;
            coords[1] = newLng;
            return coords;
        }
    }
}