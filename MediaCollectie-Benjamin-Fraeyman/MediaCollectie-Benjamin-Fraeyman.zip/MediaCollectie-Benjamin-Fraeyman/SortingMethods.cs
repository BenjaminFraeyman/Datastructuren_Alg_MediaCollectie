﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Net;
using System.Collections.Specialized;
using ExifLibrary;
using AForge;
using AForge.Imaging;
using AForge.Imaging.Filters;
using AForge.Math;
using System.Runtime.InteropServices;
using System.Collections;

namespace MediaCollectie_Benjamin_Fraeyman
{
    class SelectionSort
    {
        public static List<MediaObject> SelectSortList(List<MediaObject> mediaList)
        {
            //pos_min is short for position of minimum
            List<MediaObject> selection = new List<MediaObject>();
            selection.Add(mediaList[0]);
            for (int i = 1; i < mediaList.Count; i++)
            {
                for (int j = 0; j < selection.Count; j++)
                {
                    if (j == selection.Count - 1)
                    {
                        selection.Add(mediaList[i]);
                    }
                    if (mediaList[i].distancehuidige <= selection[j].distancehuidige)
                    {
                        selection.Insert(j, mediaList[i]);
                        j = selection.Count;
                    }
                }
            }
            return selection;
        }
    }

    class InsertionSort
    {
        public static List<MediaObject> InsertSortList(List<MediaObject> mediaList)
        {
            List<MediaObject> insertion = new List<MediaObject>();
            insertion.Add(mediaList[0]);
            for (int i = 0; i < mediaList.Count; i++)
            {
                bool plaats = false;
                int j = 0;
                while (plaats == false)
                {
                    try
                    {
                        if (mediaList[i].distancehuidige > insertion[j].distancehuidige)
                        {
                            j++;
                        }
                        else
                        {
                            insertion.Insert(j, mediaList[i]);
                            plaats = true;
                        }
                    }
                    catch
                    {
                        insertion.Add(mediaList[i]);
                    }
                }
            }
            return insertion;
        }
    }

    class BubbleSort
    {
        public static List<MediaObject> BubbleSortList(List<MediaObject> mediaList)
        {
            List<MediaObject> bubbles = new List<MediaObject>();
            foreach (MediaObject afb in mediaList)
            {
                bubbles.Add(afb);
            }
            MediaObject temp;
            for (int i = 0; i < bubbles.Count; i++)
            {
                for (int j = 0; j < bubbles.Count - 1; j++)
                {
                    if (bubbles[j].distancehuidige > bubbles[j + 1].distancehuidige)
                    {
                        temp = bubbles[j + 1];
                        bubbles[j + 1] = bubbles[j];
                        bubbles[j] = temp;
                    }
                }
            }
            return bubbles;
        }
    }
}