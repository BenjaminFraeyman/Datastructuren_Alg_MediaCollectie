﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaCollectie_Benjamin_Fraeyman
{
    class BinarySearchMethod
    {
        public static int BinarySearch(List<MediaObject> mediaList, DateTime d)
        {
            string dd = d.ToShortDateString();
            // Compare to begin, end -> outofBounds? >> stop search
            // Else >> compare to midden >> zoek verder links of rechts of gevonden
            int eerste = 0;
            int laatste = mediaList.Count() - 1;
            if ((mediaList[laatste].datum.CompareTo(d) < 0) || (mediaList[eerste].datum.CompareTo(d) > 0))
            {
                return -1;
            }
            else
            {
                int midden = 0;
                while (eerste < laatste)
                {
                    midden = eerste + ((laatste - eerste) / 2);
                    string Datumm = mediaList[midden].datum.ToShortDateString();
                    if (Datumm == dd)
                    {
                        eerste = laatste + 1;
                    }
                    Boolean zoeken = true;
                    while (zoeken)
                    {
                        if (mediaList[midden].datum.CompareTo(d) > 0)
                        {
                            eerste = midden + 1;
                            zoeken = false;
                        }
                        else if (mediaList[midden].datum.CompareTo(d) < 0)
                        {
                            laatste = midden - 1;
                            zoeken = false;
                        }
                    }
                }
                return midden;
            }
        }

        public static List<MediaObject> BinarySearchMultiples(List<MediaObject> mediaList, int waarde)
        {
            List<MediaObject> doubles = new List<MediaObject>();
            for (int eerste = 0; eerste < (mediaList.Count() - 1); eerste++)
            {
                if (mediaList[eerste].datum.ToShortDateString() == mediaList[waarde].datum.ToShortDateString())
                {
                    doubles.Add(mediaList[eerste]);
                }
            }
            return doubles;
        }

        public static int BinarySearchExtra(List<MediaObject> mediaList, DateTime d, string dd)
        {
            // Compare to begin, end -> outofBounds? >> stop search
            // Else >> compare to midden >> zoek verder links of rechts of gevonden
            int eerste = 0;
            int laatste = mediaList.Count() - 1;
            if ((mediaList[mediaList.Count() - 1].datum.CompareTo(d) < 0) || (mediaList[0].datum.CompareTo(d) > 0))
            {
                return -1;
            }
            else
            {
                int midden = 0;
                while (eerste < laatste)
                {
                    midden = eerste + ((laatste - eerste) / 2);
                    string Datumm = mediaList[midden].datum.ToShortDateString();
                    if (Datumm == dd)
                    {
                        List<string> test = new List<string>();
                        Boolean test2 = true;
                        int x = midden;
                        while ((x != eerste) && test2)
                        {
                            if (mediaList[x].datum.ToShortDateString() != Datumm)
                            {
                                test2 = false;
                            }
                            else
                            {
                                test.Add(mediaList[x].fileName);
                            }
                            x = x - 1;
                        }
                        Boolean test3 = true;
                        x = midden + 1;
                        while (x != laatste && test3)
                        {
                            if (mediaList[x].datum.ToShortDateString() != Datumm)
                            {
                                test3 = false;
                            }
                            else
                            {
                                test.Add(mediaList[x].fileName);
                            }
                            x = x + 1;
                        }
                        foreach (var item in test)
                        {
                            Console.WriteLine(item);
                        }
                    }
                    Boolean zoeken = true;
                    while (zoeken)
                    {
                        if (mediaList[midden].datum.CompareTo(d) > 0)
                        {
                            eerste = midden + 1;
                            zoeken = false;
                        }
                        else if (mediaList[midden].datum.CompareTo(d) < 0)
                        {
                            laatste = midden - 1;
                            zoeken = false;
                        }
                    }
                }
                return midden;
            }
        }
    }
}
