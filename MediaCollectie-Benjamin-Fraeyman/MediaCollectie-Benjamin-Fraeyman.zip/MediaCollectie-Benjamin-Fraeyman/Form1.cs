﻿using AForge;
using System;
using System.IO;
using System.Net;
using System.Xml;
using System.Data;
using System.Linq;
using System.Text;
using ExifLibrary;
using AForge.Math;
using System.Drawing;
using AForge.Imaging;
using System.Collections;
using System.Windows.Forms;
using System.ComponentModel;
using System.Threading.Tasks;
using AForge.Imaging.Filters;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Collections.Specialized;

namespace MediaCollectie_Benjamin_Fraeyman
{
    public partial class Form1 : Form
    {
        public static List<MediaObject> mediaList;
        string[] files;
        string cpath;
        public uint huidigelat;
        public uint huidigelon;
        public static Hashtable folderprops = new Hashtable();
        public Form1()
        {
            InitializeComponent();
            mediaList = new List<MediaObject>();
            huidigelat = 50 * 3600 + 50 * 60 + 9;
            huidigelon = 3 * 3600 + 12 * 60 + 5;
            
        }

        // controle, schrijft de volle lijst naar console
        private void WriteListToConsButton_Click(object sender, EventArgs e)
        {
            FirstImage.Image = mediaList[0].bmp;
            SecondImage.Image = mediaList[1].bmp;
            ThirdImage.Image = mediaList[2].bmp;
            int temp = mediaList.Count;
            LastImage.Image = mediaList[temp - 1].bmp;
            PreLastImage.Image = mediaList[temp - 2].bmp;
            ThirdLast.Image = mediaList[temp - 3].bmp;

            foreach (MediaObject afb in mediaList)
            {
                Console.WriteLine(" ");
                Console.WriteLine(afb.fileName);
                Console.WriteLine(afb.size);
                Console.WriteLine(afb.distancehuidige);
                Console.WriteLine(afb.grayMean);
            }
            System.Windows.Forms.MessageBox.Show("Done - Check Console");
        }

        // FileBrowser
        private void BrowserButton_Click(object sender, EventArgs e)
        {
            DialogResult result = FolderBrowser.ShowDialog();
            if (result == DialogResult.OK)
            {
                // The user selected a folder and pressed the OK button. We print the number of files found.
                mediaList.Clear();
                files = Directory.GetFiles(FolderBrowser.SelectedPath, "*.jpg");
                cpath = FolderBrowser.SelectedPath;  //Directory.GetFiles(FolderBrowser.SelectedPath, "*.props");
                FileNumberLabel.Text = "MediaFolder contains " + files.Length.ToString() + " files";
            }
            for (int fIndex = 0; fIndex < files.Length; fIndex++)
            {
                //Console.WriteLine(File.GetCreationTime(files[fIndex]));
                FileInfo fInfo = new FileInfo(files[fIndex]);
                MediaObject media = new MediaObject(files[fIndex], (int)fInfo.Length, File.GetCreationTime(files[fIndex]));
                media.AddMetaData(ImageFile.FromFile(files[fIndex]));
                media.bmp = new Bitmap(files[fIndex]);
                mediaList.Add(media);
                //Console.WriteLine(files[fIndex]);
            }
            try
            {
                folderprops.Clear();
                Hashing.DeHashItBro(cpath + "\\test.props");
            }
            catch (Exception)
            {
                Hashing.HashItBro(cpath + "\\test.props");
            }
            FirstImage.Image = mediaList[0].bmp;
            SecondImage.Image = mediaList[1].bmp;
            ThirdImage.Image = mediaList[2].bmp;
            int temp = mediaList.Count;
            LastImage.Image = mediaList[temp - 1].bmp;
            PreLastImage.Image = mediaList[temp - 2].bmp;
            ThirdLast.Image = mediaList[temp - 3].bmp;
            System.Windows.Forms.MessageBox.Show("Done - MediaList Loaded");
        }

        // Sort By Date
        private void SortByDateButton_Click(object sender, EventArgs e)
        {
            mediaList.Sort(delegate (MediaObject x, MediaObject y) { return x.datum.CompareTo(y.datum); });
            Console.WriteLine("Startdatum: " + mediaList[0].datum);
            Console.WriteLine("Einddatum: " + mediaList[mediaList.Count() - 1].datum);
            
            FirstImage.Image = mediaList[0].bmp;
            SecondImage.Image = mediaList[1].bmp;
            ThirdImage.Image = mediaList[2].bmp;
            int temp = mediaList.Count;
            LastImage.Image = mediaList[temp - 1].bmp;
            PreLastImage.Image = mediaList[temp - 2].bmp;
            ThirdLast.Image = mediaList[temp - 3].bmp;
            DateLabel.Text = Convert.ToString(mediaList[0].datum);
            System.Windows.Forms.MessageBox.Show("Done - MediaList Sorted By Date");
        }

        // Sort By Size
        private void SortBySizeButton_Click(object sender, EventArgs e)
        {
            mediaList.Sort(delegate (MediaObject x, MediaObject y) { return x.size.CompareTo(y.size); });
            Console.WriteLine("Grootste: " + mediaList[0].size + "bytes");
            FirstImage.Image = mediaList[0].bmp;
            SecondImage.Image = mediaList[1].bmp;
            ThirdImage.Image = mediaList[2].bmp;
            int temp = mediaList.Count;
            LastImage.Image = mediaList[temp - 1].bmp;
            PreLastImage.Image = mediaList[temp - 2].bmp;
            ThirdLast.Image = mediaList[temp - 3].bmp;
            SizeLabel.Text = Convert.ToString(mediaList[0].size + "Byte");
            System.Windows.Forms.MessageBox.Show("Done - MediaList Sorted By Size");
        }

        // Bin. Search
        private void BinarySearchButton_Click(object sender, EventArgs e)
        {
            mediaList.Sort(delegate (MediaObject x, MediaObject y) { return x.datum.CompareTo(y.datum); });
            DateTime d = DatePicker.Value;
            int midden = BinarySearchMethod.BinarySearch(mediaList, d);
            if (midden != -1)
            {
                Console.WriteLine("Gevonden: " + mediaList[midden].datum);
                System.Windows.Forms.MessageBox.Show("Found: " + mediaList[midden].datum);
                FirstImage.Image = mediaList[midden].bmp;
            }
            else {
                System.Windows.Forms.MessageBox.Show("Not Found");
                Console.WriteLine("Not found");}
        }
        private void BinSearchExtra_Click(object sender, EventArgs e)
        {
            mediaList.Sort(delegate (MediaObject x, MediaObject y) { return x.datum.CompareTo(y.datum); });
            DateTime d = DatePicker.Value;
            int midden = BinarySearchMethod.BinarySearch(mediaList, d);
            if (midden != -1)
            {
                Console.WriteLine("Gevonden: " + mediaList[midden].datum);
                List<MediaObject> doubles = new List<MediaObject>();
                doubles = BinarySearchMethod.BinarySearchMultiples(mediaList, midden);
                foreach (var item in doubles)
                {
                    Console.WriteLine(item.fileName);
                }
                FirstImage.Image = mediaList[midden].bmp;
                System.Windows.Forms.MessageBox.Show("Found: " + mediaList[midden].datum);
            }
            else {
                System.Windows.Forms.MessageBox.Show("Not Found");
                Console.WriteLine("Not found"); }
        }

        // Load GeoData
        private void GeoDataButton_Click(object sender, EventArgs e)
        {
            foreach (MediaObject image in mediaList)
            {
                image.Geotags();
            }
            System.Windows.Forms.MessageBox.Show("Done - GeoData Loaded");
        }

        // Sort Distance With Selection Sort Method
        private void SortByDistanceSelSortButton_Click(object sender, EventArgs e)
        {
            foreach (MediaObject afb in mediaList)
            {
                afb.Geotags();
                uint b = huidigelat - afb.distancelat;
                uint c = huidigelon - afb.distancelon;
                afb.distancehuidige = Math.Sqrt(c * c + b * b);
            }
            List<MediaObject> selection = SelectionSort.SelectSortList(mediaList);
            FirstImage.Image = selection[0].bmp;
            SecondImage.Image = selection[1].bmp;
            ThirdImage.Image = selection[2].bmp;
            int temp = mediaList.Count;
            LastImage.Image = selection[temp - 1].bmp;
            PreLastImage.Image = selection[temp - 2].bmp;
            ThirdLast.Image = selection[temp - 3].bmp;
            Console.WriteLine("Foto: " + selection[0].fileName);

            //SelectedImage.Image = selection[0].bmp;
            //SelectedLabel.Text = ("Closest Picture: {0}" + selection[0].distancehuidige);
            System.Windows.Forms.MessageBox.Show("Picture Closest: " + selection[0].fileName);
        }

        // Sort Distance With Insertion Sort Method
        private void SortByDistanceInsSortButton_Click(object sender, EventArgs e)
        {
            foreach (MediaObject afb in mediaList)
            {
                afb.Geotags();
                uint b = huidigelat - afb.distancelat;
                uint c = huidigelon - afb.distancelon;
                afb.distancehuidige = Math.Sqrt(c * c + b * b);
            }
            List<MediaObject> insertion = InsertionSort.InsertSortList(mediaList);
            FirstImage.Image = insertion[0].bmp;
            SecondImage.Image = insertion[1].bmp;
            ThirdImage.Image = insertion[2].bmp;
            int temp = mediaList.Count;
            LastImage.Image = insertion[temp - 1].bmp;
            PreLastImage.Image = insertion[temp - 2].bmp;
            ThirdLast.Image = insertion[temp - 3].bmp;
            Console.WriteLine("Foto: " + insertion[0].fileName);
            System.Windows.Forms.MessageBox.Show("Picture Closest: " + insertion[0].fileName);
        }

        // Sort Distance With Bubble Sort Method
        private void SortByDistanceBubSortButton_Click(object sender, EventArgs e)
        {
            foreach (MediaObject afb in mediaList)
            {
                afb.Geotags();
                uint b = huidigelat - afb.distancelat;
                uint c = huidigelon - afb.distancelon;
                afb.distancehuidige = Math.Sqrt(c * c + b * b);
            }
            List<MediaObject> bubbles = BubbleSort.BubbleSortList(mediaList);
            FirstImage.Image = bubbles[0].bmp;
            SecondImage.Image = bubbles[1].bmp;
            ThirdImage.Image = bubbles[2].bmp;
            int temp = mediaList.Count;
            LastImage.Image = bubbles[temp - 1].bmp;
            PreLastImage.Image = bubbles[temp - 2].bmp;
            ThirdLast.Image = bubbles[temp - 3].bmp;
            Console.WriteLine("Foto: " + bubbles[0].fileName);
            System.Windows.Forms.MessageBox.Show("Picture Closest: " + bubbles[0].fileName);
        }

        // Find Median With Median Heap, recalculate median every time
        private void MedianButton_Click(object sender, EventArgs e)
        {
            try
            {
                HEAPSS heap = new HEAPSS();
                HEAPSS.clear();
                Grayscale filter = new Grayscale(0.2125, 07154, 0.0721);
                foreach (MediaObject afb in mediaList)
                {
                    Bitmap gbmp = filter.Apply(afb.bmp);
                    ImageStatistics stats = new ImageStatistics(gbmp);
                    Histogram hist = stats.Gray;
                    afb.grayMean = hist.Mean;
                }
                mediaList.Sort(delegate (MediaObject x, MediaObject y)
                {
                    return x.grayMean.CompareTo(y.grayMean);
                });
                MediaObject median = mediaList[0];
                for (int t = 0; t < mediaList.Count; ++t)
                {
                    median = heap.AddValue(mediaList[t], median, heap);
                }
                MediaObject finalmedian = mediaList[mediaList.Count / 2];
                Console.WriteLine();
                Console.WriteLine("Beste foto:");
                Console.WriteLine(finalmedian.fileName);
                Console.WriteLine(finalmedian.grayMean);
                System.Windows.Forms.MessageBox.Show("Done - Check Console");
            }
            catch (Exception)
            {
                System.Windows.Forms.MessageBox.Show("ERROR - start programma opnieuw op of selecteer eerst een folder");
            }
        }
        // Find Median With Median Heap, calculate median at beginning
        private void MedianButton2_Click(object sender, EventArgs e)
        {
            try
            {
                Grayscale filter = new Grayscale(0.2125, 07154, 0.0721);
                foreach (MediaObject afb in mediaList)
                {
                    Bitmap gbmp = filter.Apply(afb.bmp);
                    ImageStatistics stats = new ImageStatistics(gbmp);
                    Histogram hist = stats.Gray;
                    afb.grayMean = hist.Mean;
                }
                //Berekenen mediaan
                mediaList.Sort(delegate (MediaObject x, MediaObject y)
                {
                    return x.grayMean.CompareTo(y.grayMean);
                });
                double median;
                int medianindex;
                if (mediaList.Count % 2 == 0)
                {
                    medianindex = (mediaList.Count) / 2 - 1;
                    median = (mediaList[medianindex].grayMean + mediaList[medianindex + 1].grayMean) / 2;
                }
                else
                {
                    medianindex = (mediaList.Count - 1) / 2 + 1;
                    median = mediaList[medianindex].grayMean;
                }
                //Median Heap algoritme
                Heap MaxHeap = new Heap(mediaList.Count);
                Heap MinHeap = new Heap(mediaList.Count);
                int temp = 0;
                foreach (MediaObject afb in mediaList)
                {
                    if (afb.grayMean <= median)
                    {
                        temp++;
                        MaxHeap.Insert(afb, 0);
                    }
                    else
                    {
                        MinHeap.Insert(afb, 1);
                    }
                }
                MaxHeap.DisplayHeap();
                Console.WriteLine();
                MinHeap.DisplayHeap();
                Console.WriteLine(median);
                MediaObject finalmedian = mediaList[mediaList.Count / 2];
                Console.WriteLine();
                Console.WriteLine("Beste foto:");
                Console.WriteLine(finalmedian.fileName);
                Console.WriteLine(finalmedian.grayMean);
                System.Windows.Forms.MessageBox.Show("Done - Check Console");
            }
            catch (Exception)
            {
                System.Windows.Forms.MessageBox.Show("ERROR - start programma opnieuw op of selecteer eerst een folder");
            }
        }

        // Add Property To This Folder
        private void AddPropButton_Click(object sender, EventArgs e)
        {
            
            if (PropTextBox.Text.Length > 0)
            {
                if (!PropTextBox.Text.Contains(" "))
                {
                    if (!(folderprops.ContainsKey(Hashing.CalculateHash(PropTextBox.Text))))
                    {
                        folderprops.Add(Hashing.CalculateHash(PropTextBox.Text), PropTextBox.Text);
                        System.Windows.Forms.MessageBox.Show("Done - Added To The List");
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Already Exists :/");
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("NO SPACES :/");
                }
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Nothing in box :/");
            }
        }

        // Hash List Of Properties
        private void HashButton_Click(object sender, EventArgs e)
        {
            Hashing.HashItBro(cpath + "\\test.props");
            System.Windows.Forms.MessageBox.Show("Done - List Hashed");
        }

        // DeHash List Of Properties
        private void DeHashButton_Click(object sender, EventArgs e)
        {
            try
            {
                Hashing.DeHashItBro(cpath + "\\test.props");
                System.Windows.Forms.MessageBox.Show("Done - List Loaded");
            }
            catch (Exception)
            {
                System.Windows.Forms.MessageBox.Show("Error (Waarschijnlijk bestaat het bestand nog niet, klik eerst op de hash knop)");
            }

        }

        private void SearchHashButton_Click(object sender, EventArgs e)
        {
            if (SearchBox.Text.Length > 0)
            {
                if (folderprops.ContainsKey(Hashing.CalculateHash(SearchBox.Text)))
                {
                    string prop = (string)folderprops[Hashing.CalculateHash(SearchBox.Text)];
                    System.Windows.Forms.MessageBox.Show("Found A Matching Property: " + prop);
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Nope :/");
                }
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Nothing in box :/");
            }
        }
    }
}