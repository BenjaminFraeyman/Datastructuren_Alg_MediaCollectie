﻿namespace MediaCollectie_Benjamin_Fraeyman
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DatePicker = new System.Windows.Forms.DateTimePicker();
            this.BrowserButton = new System.Windows.Forms.Button();
            this.FolderBrowser = new System.Windows.Forms.FolderBrowserDialog();
            this.FileNumberLabel = new System.Windows.Forms.Label();
            this.SortByDateButton = new System.Windows.Forms.Button();
            this.FirstImage = new System.Windows.Forms.PictureBox();
            this.SortBySizeButton = new System.Windows.Forms.Button();
            this.BinarySearchButton = new System.Windows.Forms.Button();
            this.BinSearchExtra = new System.Windows.Forms.Button();
            this.GeoDataButton = new System.Windows.Forms.Button();
            this.SortByDistanceSelSortButton = new System.Windows.Forms.Button();
            this.SortByDistanceInsSortButton = new System.Windows.Forms.Button();
            this.SortByDistanceBubSortButton = new System.Windows.Forms.Button();
            this.WriteListToConsButton = new System.Windows.Forms.Button();
            this.MedianButton = new System.Windows.Forms.Button();
            this.AddPropButton = new System.Windows.Forms.Button();
            this.PropTextBox = new System.Windows.Forms.TextBox();
            this.HashButton = new System.Windows.Forms.Button();
            this.DeHashButton = new System.Windows.Forms.Button();
            this.SearchHashButton = new System.Windows.Forms.Button();
            this.SearchBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.FirstLabel = new System.Windows.Forms.Label();
            this.SecondLabel = new System.Windows.Forms.Label();
            this.ThirdLabel = new System.Windows.Forms.Label();
            this.SecondImage = new System.Windows.Forms.PictureBox();
            this.ThirdImage = new System.Windows.Forms.PictureBox();
            this.ThirdLast = new System.Windows.Forms.PictureBox();
            this.PreLastImage = new System.Windows.Forms.PictureBox();
            this.LastImage = new System.Windows.Forms.PictureBox();
            this.ThirdLastLabel = new System.Windows.Forms.Label();
            this.PreLastLabel = new System.Windows.Forms.Label();
            this.LastLabel = new System.Windows.Forms.Label();
            this.DateLabel = new System.Windows.Forms.Label();
            this.SizeLabel = new System.Windows.Forms.Label();
            this.MedianButton2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.FirstImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SecondImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThirdImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThirdLast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PreLastImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LastImage)).BeginInit();
            this.SuspendLayout();
            // 
            // DatePicker
            // 
            this.DatePicker.CalendarFont = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DatePicker.CalendarForeColor = System.Drawing.Color.Yellow;
            this.DatePicker.CalendarMonthBackground = System.Drawing.Color.Magenta;
            this.DatePicker.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DatePicker.CalendarTitleForeColor = System.Drawing.Color.Yellow;
            this.DatePicker.Location = new System.Drawing.Point(12, 12);
            this.DatePicker.Name = "DatePicker";
            this.DatePicker.Size = new System.Drawing.Size(200, 20);
            this.DatePicker.TabIndex = 0;
            // 
            // BrowserButton
            // 
            this.BrowserButton.BackColor = System.Drawing.Color.Magenta;
            this.BrowserButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BrowserButton.ForeColor = System.Drawing.Color.Yellow;
            this.BrowserButton.Location = new System.Drawing.Point(12, 38);
            this.BrowserButton.Name = "BrowserButton";
            this.BrowserButton.Size = new System.Drawing.Size(200, 42);
            this.BrowserButton.TabIndex = 1;
            this.BrowserButton.Text = "Open Folder";
            this.BrowserButton.UseVisualStyleBackColor = false;
            this.BrowserButton.Click += new System.EventHandler(this.BrowserButton_Click);
            // 
            // FileNumberLabel
            // 
            this.FileNumberLabel.AutoSize = true;
            this.FileNumberLabel.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FileNumberLabel.ForeColor = System.Drawing.Color.Yellow;
            this.FileNumberLabel.Location = new System.Drawing.Point(218, 38);
            this.FileNumberLabel.Name = "FileNumberLabel";
            this.FileNumberLabel.Size = new System.Drawing.Size(104, 28);
            this.FileNumberLabel.TabIndex = 2;
            this.FileNumberLabel.Text = "# of files";
            // 
            // SortByDateButton
            // 
            this.SortByDateButton.BackColor = System.Drawing.Color.Magenta;
            this.SortByDateButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SortByDateButton.ForeColor = System.Drawing.Color.Yellow;
            this.SortByDateButton.Location = new System.Drawing.Point(12, 86);
            this.SortByDateButton.Name = "SortByDateButton";
            this.SortByDateButton.Size = new System.Drawing.Size(200, 42);
            this.SortByDateButton.TabIndex = 3;
            this.SortByDateButton.Text = "Sort By Date";
            this.SortByDateButton.UseVisualStyleBackColor = false;
            this.SortByDateButton.Click += new System.EventHandler(this.SortByDateButton_Click);
            // 
            // FirstImage
            // 
            this.FirstImage.Location = new System.Drawing.Point(526, 45);
            this.FirstImage.Name = "FirstImage";
            this.FirstImage.Size = new System.Drawing.Size(189, 164);
            this.FirstImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.FirstImage.TabIndex = 4;
            this.FirstImage.TabStop = false;
            // 
            // SortBySizeButton
            // 
            this.SortBySizeButton.BackColor = System.Drawing.Color.Magenta;
            this.SortBySizeButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SortBySizeButton.ForeColor = System.Drawing.Color.Yellow;
            this.SortBySizeButton.Location = new System.Drawing.Point(12, 134);
            this.SortBySizeButton.Name = "SortBySizeButton";
            this.SortBySizeButton.Size = new System.Drawing.Size(200, 42);
            this.SortBySizeButton.TabIndex = 5;
            this.SortBySizeButton.Text = "Sort By Size";
            this.SortBySizeButton.UseVisualStyleBackColor = false;
            this.SortBySizeButton.Click += new System.EventHandler(this.SortBySizeButton_Click);
            // 
            // BinarySearchButton
            // 
            this.BinarySearchButton.BackColor = System.Drawing.Color.Magenta;
            this.BinarySearchButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BinarySearchButton.ForeColor = System.Drawing.Color.Yellow;
            this.BinarySearchButton.Location = new System.Drawing.Point(12, 182);
            this.BinarySearchButton.Name = "BinarySearchButton";
            this.BinarySearchButton.Size = new System.Drawing.Size(200, 42);
            this.BinarySearchButton.TabIndex = 6;
            this.BinarySearchButton.Text = "Bin. Search";
            this.BinarySearchButton.UseVisualStyleBackColor = false;
            this.BinarySearchButton.Click += new System.EventHandler(this.BinarySearchButton_Click);
            // 
            // BinSearchExtra
            // 
            this.BinSearchExtra.BackColor = System.Drawing.Color.Magenta;
            this.BinSearchExtra.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BinSearchExtra.ForeColor = System.Drawing.Color.Yellow;
            this.BinSearchExtra.Location = new System.Drawing.Point(12, 230);
            this.BinSearchExtra.Name = "BinSearchExtra";
            this.BinSearchExtra.Size = new System.Drawing.Size(200, 42);
            this.BinSearchExtra.TabIndex = 7;
            this.BinSearchExtra.Text = "Bin. Search (Extra)";
            this.BinSearchExtra.UseVisualStyleBackColor = false;
            this.BinSearchExtra.Click += new System.EventHandler(this.BinSearchExtra_Click);
            // 
            // GeoDataButton
            // 
            this.GeoDataButton.BackColor = System.Drawing.Color.Magenta;
            this.GeoDataButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GeoDataButton.ForeColor = System.Drawing.Color.Yellow;
            this.GeoDataButton.Location = new System.Drawing.Point(12, 278);
            this.GeoDataButton.Name = "GeoDataButton";
            this.GeoDataButton.Size = new System.Drawing.Size(200, 42);
            this.GeoDataButton.TabIndex = 8;
            this.GeoDataButton.Text = "Load GeoData";
            this.GeoDataButton.UseVisualStyleBackColor = false;
            this.GeoDataButton.Click += new System.EventHandler(this.GeoDataButton_Click);
            // 
            // SortByDistanceSelSortButton
            // 
            this.SortByDistanceSelSortButton.BackColor = System.Drawing.Color.Magenta;
            this.SortByDistanceSelSortButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SortByDistanceSelSortButton.ForeColor = System.Drawing.Color.Yellow;
            this.SortByDistanceSelSortButton.Location = new System.Drawing.Point(12, 327);
            this.SortByDistanceSelSortButton.Name = "SortByDistanceSelSortButton";
            this.SortByDistanceSelSortButton.Size = new System.Drawing.Size(310, 43);
            this.SortByDistanceSelSortButton.TabIndex = 9;
            this.SortByDistanceSelSortButton.Text = "Sort By Distance (Sel. Sort)";
            this.SortByDistanceSelSortButton.UseVisualStyleBackColor = false;
            this.SortByDistanceSelSortButton.Click += new System.EventHandler(this.SortByDistanceSelSortButton_Click);
            // 
            // SortByDistanceInsSortButton
            // 
            this.SortByDistanceInsSortButton.BackColor = System.Drawing.Color.Magenta;
            this.SortByDistanceInsSortButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SortByDistanceInsSortButton.ForeColor = System.Drawing.Color.Yellow;
            this.SortByDistanceInsSortButton.Location = new System.Drawing.Point(12, 376);
            this.SortByDistanceInsSortButton.Name = "SortByDistanceInsSortButton";
            this.SortByDistanceInsSortButton.Size = new System.Drawing.Size(310, 42);
            this.SortByDistanceInsSortButton.TabIndex = 10;
            this.SortByDistanceInsSortButton.Text = "Sort By Distance (Ins. Sort)";
            this.SortByDistanceInsSortButton.UseVisualStyleBackColor = false;
            this.SortByDistanceInsSortButton.Click += new System.EventHandler(this.SortByDistanceInsSortButton_Click);
            // 
            // SortByDistanceBubSortButton
            // 
            this.SortByDistanceBubSortButton.BackColor = System.Drawing.Color.Magenta;
            this.SortByDistanceBubSortButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SortByDistanceBubSortButton.ForeColor = System.Drawing.Color.Yellow;
            this.SortByDistanceBubSortButton.Location = new System.Drawing.Point(12, 426);
            this.SortByDistanceBubSortButton.Name = "SortByDistanceBubSortButton";
            this.SortByDistanceBubSortButton.Size = new System.Drawing.Size(310, 42);
            this.SortByDistanceBubSortButton.TabIndex = 11;
            this.SortByDistanceBubSortButton.Text = "Sort By Distance (Bub. Sort)";
            this.SortByDistanceBubSortButton.UseVisualStyleBackColor = false;
            this.SortByDistanceBubSortButton.Click += new System.EventHandler(this.SortByDistanceBubSortButton_Click);
            // 
            // WriteListToConsButton
            // 
            this.WriteListToConsButton.BackColor = System.Drawing.Color.Magenta;
            this.WriteListToConsButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WriteListToConsButton.ForeColor = System.Drawing.Color.Yellow;
            this.WriteListToConsButton.Location = new System.Drawing.Point(12, 714);
            this.WriteListToConsButton.Name = "WriteListToConsButton";
            this.WriteListToConsButton.Size = new System.Drawing.Size(96, 36);
            this.WriteListToConsButton.TabIndex = 12;
            this.WriteListToConsButton.Text = "Control";
            this.WriteListToConsButton.UseVisualStyleBackColor = false;
            this.WriteListToConsButton.Click += new System.EventHandler(this.WriteListToConsButton_Click);
            // 
            // MedianButton
            // 
            this.MedianButton.BackColor = System.Drawing.Color.Magenta;
            this.MedianButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MedianButton.ForeColor = System.Drawing.Color.Yellow;
            this.MedianButton.Location = new System.Drawing.Point(12, 474);
            this.MedianButton.Name = "MedianButton";
            this.MedianButton.Size = new System.Drawing.Size(163, 42);
            this.MedianButton.TabIndex = 13;
            this.MedianButton.Text = "Median - Slow";
            this.MedianButton.UseVisualStyleBackColor = false;
            this.MedianButton.Click += new System.EventHandler(this.MedianButton_Click);
            // 
            // AddPropButton
            // 
            this.AddPropButton.BackColor = System.Drawing.Color.Magenta;
            this.AddPropButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddPropButton.ForeColor = System.Drawing.Color.Yellow;
            this.AddPropButton.Location = new System.Drawing.Point(12, 522);
            this.AddPropButton.Name = "AddPropButton";
            this.AddPropButton.Size = new System.Drawing.Size(163, 42);
            this.AddPropButton.TabIndex = 14;
            this.AddPropButton.Text = "Add Property:";
            this.AddPropButton.UseVisualStyleBackColor = false;
            this.AddPropButton.Click += new System.EventHandler(this.AddPropButton_Click);
            // 
            // PropTextBox
            // 
            this.PropTextBox.BackColor = System.Drawing.Color.Magenta;
            this.PropTextBox.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PropTextBox.ForeColor = System.Drawing.Color.Yellow;
            this.PropTextBox.Location = new System.Drawing.Point(181, 526);
            this.PropTextBox.Name = "PropTextBox";
            this.PropTextBox.Size = new System.Drawing.Size(188, 35);
            this.PropTextBox.TabIndex = 15;
            this.PropTextBox.Text = "TypePropertyHere";
            // 
            // HashButton
            // 
            this.HashButton.BackColor = System.Drawing.Color.Magenta;
            this.HashButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HashButton.ForeColor = System.Drawing.Color.Yellow;
            this.HashButton.Location = new System.Drawing.Point(12, 570);
            this.HashButton.Name = "HashButton";
            this.HashButton.Size = new System.Drawing.Size(163, 42);
            this.HashButton.TabIndex = 16;
            this.HashButton.Text = "Hash Props";
            this.HashButton.UseVisualStyleBackColor = false;
            this.HashButton.Click += new System.EventHandler(this.HashButton_Click);
            // 
            // DeHashButton
            // 
            this.DeHashButton.BackColor = System.Drawing.Color.Magenta;
            this.DeHashButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeHashButton.ForeColor = System.Drawing.Color.Yellow;
            this.DeHashButton.Location = new System.Drawing.Point(12, 618);
            this.DeHashButton.Name = "DeHashButton";
            this.DeHashButton.Size = new System.Drawing.Size(163, 42);
            this.DeHashButton.TabIndex = 17;
            this.DeHashButton.Text = "DeHash Props";
            this.DeHashButton.UseVisualStyleBackColor = false;
            this.DeHashButton.Click += new System.EventHandler(this.DeHashButton_Click);
            // 
            // SearchHashButton
            // 
            this.SearchHashButton.BackColor = System.Drawing.Color.Magenta;
            this.SearchHashButton.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchHashButton.ForeColor = System.Drawing.Color.Yellow;
            this.SearchHashButton.Location = new System.Drawing.Point(12, 666);
            this.SearchHashButton.Name = "SearchHashButton";
            this.SearchHashButton.Size = new System.Drawing.Size(163, 42);
            this.SearchHashButton.TabIndex = 18;
            this.SearchHashButton.Text = "Search Prop:";
            this.SearchHashButton.UseVisualStyleBackColor = false;
            this.SearchHashButton.Click += new System.EventHandler(this.SearchHashButton_Click);
            // 
            // SearchBox
            // 
            this.SearchBox.BackColor = System.Drawing.Color.Magenta;
            this.SearchBox.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchBox.ForeColor = System.Drawing.Color.Yellow;
            this.SearchBox.Location = new System.Drawing.Point(181, 670);
            this.SearchBox.Name = "SearchBox";
            this.SearchBox.Size = new System.Drawing.Size(188, 35);
            this.SearchBox.TabIndex = 19;
            this.SearchBox.Text = "TypePropertyHere";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(114, 718);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(798, 28);
            this.label1.TabIndex = 20;
            this.label1.Text = "Writes out the medialist to console with some properties so you can check the ord" +
    "er";
            // 
            // FirstLabel
            // 
            this.FirstLabel.AutoSize = true;
            this.FirstLabel.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstLabel.ForeColor = System.Drawing.Color.Yellow;
            this.FirstLabel.Location = new System.Drawing.Point(477, 23);
            this.FirstLabel.Name = "FirstLabel";
            this.FirstLabel.Size = new System.Drawing.Size(271, 19);
            this.FirstLabel.TabIndex = 21;
            this.FirstLabel.Text = "Eerste Foto In Lijst / opgevraagde foto";
            // 
            // SecondLabel
            // 
            this.SecondLabel.AutoSize = true;
            this.SecondLabel.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SecondLabel.ForeColor = System.Drawing.Color.Yellow;
            this.SecondLabel.Location = new System.Drawing.Point(477, 212);
            this.SecondLabel.Name = "SecondLabel";
            this.SecondLabel.Size = new System.Drawing.Size(150, 19);
            this.SecondLabel.TabIndex = 22;
            this.SecondLabel.Text = "Tweede Foto In Lijst";
            // 
            // ThirdLabel
            // 
            this.ThirdLabel.AutoSize = true;
            this.ThirdLabel.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThirdLabel.ForeColor = System.Drawing.Color.Yellow;
            this.ThirdLabel.Location = new System.Drawing.Point(477, 373);
            this.ThirdLabel.Name = "ThirdLabel";
            this.ThirdLabel.Size = new System.Drawing.Size(139, 19);
            this.ThirdLabel.TabIndex = 23;
            this.ThirdLabel.Text = "Derde Foto In Lijst";
            // 
            // SecondImage
            // 
            this.SecondImage.Location = new System.Drawing.Point(481, 234);
            this.SecondImage.Name = "SecondImage";
            this.SecondImage.Size = new System.Drawing.Size(140, 136);
            this.SecondImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SecondImage.TabIndex = 24;
            this.SecondImage.TabStop = false;
            // 
            // ThirdImage
            // 
            this.ThirdImage.Location = new System.Drawing.Point(481, 395);
            this.ThirdImage.Name = "ThirdImage";
            this.ThirdImage.Size = new System.Drawing.Size(140, 136);
            this.ThirdImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ThirdImage.TabIndex = 25;
            this.ThirdImage.TabStop = false;
            // 
            // ThirdLast
            // 
            this.ThirdLast.Location = new System.Drawing.Point(627, 234);
            this.ThirdLast.Name = "ThirdLast";
            this.ThirdLast.Size = new System.Drawing.Size(140, 136);
            this.ThirdLast.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ThirdLast.TabIndex = 26;
            this.ThirdLast.TabStop = false;
            // 
            // PreLastImage
            // 
            this.PreLastImage.Location = new System.Drawing.Point(627, 395);
            this.PreLastImage.Name = "PreLastImage";
            this.PreLastImage.Size = new System.Drawing.Size(140, 136);
            this.PreLastImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PreLastImage.TabIndex = 27;
            this.PreLastImage.TabStop = false;
            // 
            // LastImage
            // 
            this.LastImage.Location = new System.Drawing.Point(627, 556);
            this.LastImage.Name = "LastImage";
            this.LastImage.Size = new System.Drawing.Size(140, 136);
            this.LastImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LastImage.TabIndex = 28;
            this.LastImage.TabStop = false;
            // 
            // ThirdLastLabel
            // 
            this.ThirdLastLabel.AutoSize = true;
            this.ThirdLastLabel.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThirdLastLabel.ForeColor = System.Drawing.Color.Yellow;
            this.ThirdLastLabel.Location = new System.Drawing.Point(623, 212);
            this.ThirdLastLabel.Name = "ThirdLastLabel";
            this.ThirdLastLabel.Size = new System.Drawing.Size(139, 19);
            this.ThirdLastLabel.TabIndex = 29;
            this.ThirdLastLabel.Text = "Derde Laatste Foto";
            // 
            // PreLastLabel
            // 
            this.PreLastLabel.AutoSize = true;
            this.PreLastLabel.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PreLastLabel.ForeColor = System.Drawing.Color.Yellow;
            this.PreLastLabel.Location = new System.Drawing.Point(628, 373);
            this.PreLastLabel.Name = "PreLastLabel";
            this.PreLastLabel.Size = new System.Drawing.Size(120, 19);
            this.PreLastLabel.TabIndex = 30;
            this.PreLastLabel.Text = "Voorlaatste Foto";
            // 
            // LastLabel
            // 
            this.LastLabel.AutoSize = true;
            this.LastLabel.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastLabel.ForeColor = System.Drawing.Color.Yellow;
            this.LastLabel.Location = new System.Drawing.Point(623, 534);
            this.LastLabel.Name = "LastLabel";
            this.LastLabel.Size = new System.Drawing.Size(149, 19);
            this.LastLabel.TabIndex = 31;
            this.LastLabel.Text = "Laatste Foto In Lijst";
            // 
            // DateLabel
            // 
            this.DateLabel.AutoSize = true;
            this.DateLabel.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateLabel.ForeColor = System.Drawing.Color.Yellow;
            this.DateLabel.Location = new System.Drawing.Point(218, 93);
            this.DateLabel.Name = "DateLabel";
            this.DateLabel.Size = new System.Drawing.Size(107, 28);
            this.DateLabel.TabIndex = 32;
            this.DateLabel.Text = "First Date";
            // 
            // SizeLabel
            // 
            this.SizeLabel.AutoSize = true;
            this.SizeLabel.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SizeLabel.ForeColor = System.Drawing.Color.Yellow;
            this.SizeLabel.Location = new System.Drawing.Point(218, 141);
            this.SizeLabel.Name = "SizeLabel";
            this.SizeLabel.Size = new System.Drawing.Size(130, 28);
            this.SizeLabel.TabIndex = 33;
            this.SizeLabel.Text = "Biggest Size";
            // 
            // MedianButton2
            // 
            this.MedianButton2.BackColor = System.Drawing.Color.Magenta;
            this.MedianButton2.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MedianButton2.ForeColor = System.Drawing.Color.Yellow;
            this.MedianButton2.Location = new System.Drawing.Point(181, 474);
            this.MedianButton2.Name = "MedianButton2";
            this.MedianButton2.Size = new System.Drawing.Size(167, 42);
            this.MedianButton2.TabIndex = 34;
            this.MedianButton2.Text = "Median - Fast";
            this.MedianButton2.UseVisualStyleBackColor = false;
            this.MedianButton2.Click += new System.EventHandler(this.MedianButton2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(947, 754);
            this.Controls.Add(this.MedianButton2);
            this.Controls.Add(this.SizeLabel);
            this.Controls.Add(this.DateLabel);
            this.Controls.Add(this.LastLabel);
            this.Controls.Add(this.PreLastLabel);
            this.Controls.Add(this.ThirdLastLabel);
            this.Controls.Add(this.LastImage);
            this.Controls.Add(this.PreLastImage);
            this.Controls.Add(this.ThirdLast);
            this.Controls.Add(this.ThirdImage);
            this.Controls.Add(this.SecondImage);
            this.Controls.Add(this.ThirdLabel);
            this.Controls.Add(this.SecondLabel);
            this.Controls.Add(this.FirstLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SearchBox);
            this.Controls.Add(this.SearchHashButton);
            this.Controls.Add(this.DeHashButton);
            this.Controls.Add(this.HashButton);
            this.Controls.Add(this.PropTextBox);
            this.Controls.Add(this.AddPropButton);
            this.Controls.Add(this.MedianButton);
            this.Controls.Add(this.WriteListToConsButton);
            this.Controls.Add(this.SortByDistanceBubSortButton);
            this.Controls.Add(this.SortByDistanceInsSortButton);
            this.Controls.Add(this.SortByDistanceSelSortButton);
            this.Controls.Add(this.GeoDataButton);
            this.Controls.Add(this.BinSearchExtra);
            this.Controls.Add(this.BinarySearchButton);
            this.Controls.Add(this.SortBySizeButton);
            this.Controls.Add(this.FirstImage);
            this.Controls.Add(this.SortByDateButton);
            this.Controls.Add(this.FileNumberLabel);
            this.Controls.Add(this.BrowserButton);
            this.Controls.Add(this.DatePicker);
            this.Name = "Form1";
            this.Text = "MediaCollectie";
            ((System.ComponentModel.ISupportInitialize)(this.FirstImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SecondImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThirdImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThirdLast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PreLastImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LastImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker DatePicker;
        private System.Windows.Forms.Button BrowserButton;
        private System.Windows.Forms.FolderBrowserDialog FolderBrowser;
        private System.Windows.Forms.Label FileNumberLabel;
        private System.Windows.Forms.Button SortByDateButton;
        private System.Windows.Forms.PictureBox FirstImage;
        private System.Windows.Forms.Button SortBySizeButton;
        private System.Windows.Forms.Button BinarySearchButton;
        private System.Windows.Forms.Button BinSearchExtra;
        private System.Windows.Forms.Button GeoDataButton;
        private System.Windows.Forms.Button SortByDistanceSelSortButton;
        private System.Windows.Forms.Button SortByDistanceInsSortButton;
        private System.Windows.Forms.Button SortByDistanceBubSortButton;
        private System.Windows.Forms.Button WriteListToConsButton;
        private System.Windows.Forms.Button MedianButton;
        private System.Windows.Forms.Button AddPropButton;
        private System.Windows.Forms.TextBox PropTextBox;
        private System.Windows.Forms.Button HashButton;
        private System.Windows.Forms.Button DeHashButton;
        private System.Windows.Forms.Button SearchHashButton;
        private System.Windows.Forms.TextBox SearchBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label FirstLabel;
        private System.Windows.Forms.Label SecondLabel;
        private System.Windows.Forms.Label ThirdLabel;
        private System.Windows.Forms.PictureBox SecondImage;
        private System.Windows.Forms.PictureBox ThirdImage;
        private System.Windows.Forms.PictureBox ThirdLast;
        private System.Windows.Forms.PictureBox PreLastImage;
        private System.Windows.Forms.PictureBox LastImage;
        private System.Windows.Forms.Label ThirdLastLabel;
        private System.Windows.Forms.Label PreLastLabel;
        private System.Windows.Forms.Label LastLabel;
        private System.Windows.Forms.Label DateLabel;
        private System.Windows.Forms.Label SizeLabel;
        private System.Windows.Forms.Button MedianButton2;
    }
}

