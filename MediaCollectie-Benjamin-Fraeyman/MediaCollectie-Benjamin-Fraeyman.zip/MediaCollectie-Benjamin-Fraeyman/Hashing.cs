﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Net;
using System.Collections.Specialized;
using ExifLibrary;
using AForge;
using AForge.Imaging;
using AForge.Imaging.Filters;
using AForge.Math;
using System.Runtime.InteropServices;
using System.Collections;

namespace MediaCollectie_Benjamin_Fraeyman
{
    class Hashing
    {
        public static UInt64 CalculateHash(string read)
        {
            UInt64 hashedValue = 1234567896969691ul;
            for (int i = 0; i < read.Length; i++)
            {
                hashedValue += read[i];
                hashedValue *= 1234567896969699ul;
            }
            return hashedValue;
        }

        public static void HashItBro(string cPath)
        {
            if (File.Exists(cPath)) File.Delete(cPath);
            // write the data to a file
            var binformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
            using (var fs = File.Create(cPath))
            {
                binformatter.Serialize(fs, Form1.folderprops);
            }
        }

        public static void DeHashItBro(string cPath)
        {
            // read the data from the file
            Form1.folderprops.Clear();
            var binformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
            using (var fs = File.Open(cPath, FileMode.Open))
            {
                Form1.folderprops = (Hashtable)binformatter.Deserialize(fs);
            }
        }
    }
}
