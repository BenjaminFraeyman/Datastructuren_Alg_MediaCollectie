﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaCollectie_Benjamin_Fraeyman
{
    public class HEAPSS
    {
        public static void Tostring()
        {
            Console.WriteLine("MAXHEAP: ");
           foreach (MediaObject item in maxh)
            {
                Console.WriteLine(item.grayMean);
            }
            Console.WriteLine();
            Console.WriteLine("MinHEAP: ");
            foreach (MediaObject item in minh)
            {
                Console.WriteLine(item.grayMean);
            }
        }
        public static List<MediaObject> maxh = new List<MediaObject>();
        public static List<MediaObject> minh = new List<MediaObject>();
        
        private static int heapSizemax = -1;
        private static int heapSizemin = -1;
        public int GetCount(int heap)
        {
            if (heap == 1)
            {
                return heapSizemax + 1;
            }
            else
            {
                return heapSizemin + 1;
            }
        }
        protected bool Compare(int a, int b, int heap)
        {
            if (heap == 1)
            {
                return a > b;
            }
            else
            {
                return a < b;
            }

        }
        public void Insert(MediaObject key, int heap)
        {
            if (heap == 1)
            {
                heapSizemax = heapSizemax + 1;
                maxh.Add(key);
                Heapify(heapSizemax, heap);
                Console.WriteLine("inserted leftheap");
            }
            else
            {
                heapSizemin = heapSizemin+1;
                minh.Add(key);
                Heapify(heapSizemin, heap);
                Console.WriteLine("inserted rightheap");
            }
        }

        public MediaObject GetTop(int heap)
        {
            if (heap == 1)
            {
                MediaObject max;
                if (heapSizemax >= 0)
                {
                    max = maxh[0];
                    return max;
                }
                return null;
            }
            else
            {
                MediaObject max;
                if (heapSizemin >= 0)
                {
                    max = minh[0];
                    return max;
                }
                return null;
            }
        }

        public MediaObject ExtractTop(int heap)
        {
            if (heap == 1)
            {
                MediaObject del;
                if (heapSizemax > -1)
                {
                    del = maxh[0];
                    Swap(maxh, 0, heapSizemax);
                    heapSizemax = heapSizemax - 1; ;
                    Heapify(GetParent(heapSizemax + 1), heap);
                    Console.WriteLine("item deleted leftheap");
                    return del;
                }
                return null;
            }
            else
            {
                MediaObject del;
                if (heapSizemin > -1)
                {
                    del = minh[0];
                    Swap(minh, 0, heapSizemin);
                    heapSizemin = heapSizemin - 1;
                    Heapify(GetParent(heapSizemin + 1), heap);
                    Console.WriteLine("item deleted rightheap");
                    return del;
                }
                return null;
            }
        }

        private static void Swap(List<MediaObject> array, int aIndex, int bIndex)
        {
            var aux = array[aIndex];
            array[aIndex] = array[bIndex];
            array[bIndex] = aux;
        }

        private int GetParent(int i)
        {
            if (i <= 0)
            {
                return -1;
            }
            return (i - 1) / 2;
        }

        private void Heapify(int i, int heap)
        {
            if (heap == 1)
            {
                int p = GetParent(i);
                if (p >= 0 && Compare(Convert.ToInt32(maxh[i].grayMean), Convert.ToInt32(maxh[p].grayMean), 1))
                {
                    Swap(maxh, i, p);
                    Heapify(p, heap);
                }
            }
            else
            {
                int p = GetParent(i);
                if (p >= 0 && Compare(Convert.ToInt32(minh[i].grayMean), Convert.ToInt32(minh[p].grayMean), heap))
                {
                    Swap(minh, i, p);
                    Heapify(p, heap);
                }
            }
        }

        public MediaObject AddValue(MediaObject newitem, MediaObject prevMedian, HEAPSS heap)
        {

            int maxheapcount = heap.GetCount(1);
            int minheapcount = heap.GetCount(0);

            if (maxheapcount > minheapcount)
            {
                Console.WriteLine("maxheapcount > minheapcount");
                if (Convert.ToInt32(newitem.grayMean) < Convert.ToInt32(prevMedian.grayMean))
                {
                    Console.WriteLine("newitem.grayMean < prevMedian.grayMean");
                    heap.Insert(heap.ExtractTop(1), 0);
                    heap.Insert(newitem, 1);
                }
                else
                {
                    Console.WriteLine("newitem.grayMean > prevMedian.grayMean");
                    heap.Insert(newitem, 0);
                }
                return heap.GetTop(1);
            }
            if (maxheapcount == minheapcount)
            {
                Console.WriteLine("maxheapcount == minheapcount");
                if (Convert.ToInt32(newitem.grayMean) > Convert.ToInt32(prevMedian.grayMean))
                {
                    Console.WriteLine("newitem.grayMean > prevMedian.grayMean");
                    heap.Insert(newitem, 1);
                    return heap.GetTop(1);
                }
                else
                {
                    Console.WriteLine("newitem.grayMean < prevMedian.grayMean");
                    heap.Insert(newitem, 0);
                    return heap.GetTop(0);
                }
            }
            else
            {
                Console.WriteLine("maxheapcount < minheapcount");
                if (Convert.ToInt32(newitem.grayMean) < Convert.ToInt32(prevMedian.grayMean))
                {
                    Console.WriteLine("newitem.grayMean < prevMedian.grayMean");
                    heap.Insert(newitem, 1);
                }
                else
                {
                    Console.WriteLine("newitem.grayMean > prevMedian.grayMean");
                    heap.Insert(heap.ExtractTop(0), 1);
                    heap.Insert(newitem, 0);
                }
                return heap.GetTop(0);
            }
        }

        public static void clear()
        {
            maxh.Clear();
            minh.Clear();
            heapSizemax = -1;
            heapSizemin = -1;
        }
    }

    public class Heap
    {
        private MediaObject[] heapArray;
        private int maxSize;
        private int size;
        public Heap(int maxHeapSize)
        {
            maxSize = maxHeapSize;
            size = 0;
            heapArray = new MediaObject[maxSize];
        }
        public void Insert(MediaObject afb, int heap)
        {
            heapArray[size] = afb;
            if (heap == 1)
            {
                CascadeDown(size++);
            }
            else
            {
                CascadeUp(size++);
            }
        }
        public void CascadeUp(int index)
        {
            int parent = (index - 1) / 2;
            MediaObject bottom = heapArray[index];
            while (index > 0 && heapArray[parent].grayMean < bottom.grayMean)
            {
                heapArray[index] = heapArray[parent];
                index = parent;
                parent = (parent - 1) / 2;
            }
            heapArray[index] = bottom;
        }
        public void CascadeDown(int index)
        {
            int larger;
            MediaObject top = heapArray[index];
            while (index < size / 2)
            {
                int left = 2 * index + 1;
                int right = left + 1;
                if (right < size && heapArray[left].grayMean < heapArray[right].grayMean)
                    larger = right;
                else
                    larger = left;
                if (top.grayMean >= heapArray[larger].grayMean)
                    break;
                heapArray[index] = heapArray[larger];
                index = larger;
            }
            heapArray[index] = top;
        }
        public void Remove() // verwijderen
        {
            heapArray[0] = heapArray[--size];
            CascadeDown(0);

        }
        public void DisplayHeap()
        {
            int emptyLeaf = 50;
            int itemsPerRow = 1;
            int column = 0;
            int j = 0;

            while (size > 0)
            {
                if (column == 0)
                    for (int k = 0; k < emptyLeaf; k++)
                        Console.Write(' ');
                Console.Write(heapArray[j].grayMean);

                if (++j == size)
                    break;
                if (++column == itemsPerRow)
                {
                    emptyLeaf /= 2;
                    itemsPerRow *= 2;
                    column = 0;
                    Console.WriteLine();
                }
                else
                    for (int k = 0; k < emptyLeaf * 2 - 2; k++)
                        Console.Write(' ');
            }
            Console.WriteLine();
            Console.WriteLine();
        }
    }
}